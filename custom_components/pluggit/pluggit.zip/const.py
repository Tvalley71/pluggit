"""The constants."""

DOMAIN = "pluggit"
DEFAULT_NAME = "Pluggit"
DEFAULT_SCAN_INTERVAL = 10
DEFAULT_PORT = 502

DEVICE_TYPES = {
    2: "AP310",
}
